// Debugging.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
/*#include "..\ADSRMathbase\typedef.h"*/
/*#include "..\ADSRMathbase\Mathbase.h"*/
// #include "..\ADSRMathbase\Matrix.cpp"
// #include "..\ADSRMathbase\Mathbase.cpp"
// #include "..\ADSRMathbase\Matrix.h"
#include "../ADSRalgorithms/BaseHD.h"
#include "../ADSRalgorithms/SI_class.h"
#include "../ADSRalgorithms/TS_class.h"
// #include "../ADSRalgorithms/TS_class.h"
//#include "../ADSRalgorithms/preferST.h"
//#include "../ADSRalgorithms/WNG.h"
// #include <string>
// #include <stdlib.h>
//"../ADSRalgorithms/WNG.h"

using namespace std;

void main()
{

	int tempkey;

try
{
	/////////////////////////////////
	// SI
	//////////////////////////////////
	SYSTEMSETTING SS;

	SS.FRONTEND.m_nInput_Channels=1;
	SS.FRONTEND.m_nResponse_Channels=1;
	SS.SPECTRAL.m_nBlocksize=8;
	SS.SPECTRAL.m_nStartFreqIndex=1;		// ���ļ��� ���ϴ� ����Ʈ��.
	SS.SPECTRAL.m_nStopFreqIndex=3;
	SS.SI.m_nSignalsPoints=16;
	SS.SPECTRAL.m_nPshifted=8;

	SS.SPECTRAL.m_nWindow=0; // 0=hann 3=rect

	SS.SI.m_nWhiteNoiseAdded=2;
	SS.FRONTEND.m_nSamplingFreq=8;
	SS.SPECTRAL.m_nCyclicAveg=1;
	SS.SI.m_nWhiteNoiseBorderFreqIndex=1;
	SS.SI.m_dbWhiteNoiseAlpha=1;
	SS.SI.m_dbWhiteNoiseSTD=1;

	SYSTEMIDENTIFICATION SI(SS);

		SI.m_WHN_driver[0][0]=1.2622;  SI.m_WHN_driver[0][1]=0.6806; SI.m_WHN_driver[0][2]=-0.8105; SI.m_WHN_driver[0][3]=0.4656;
		SI.m_WHN_driver[0][4]=-1.2622; SI.m_WHN_driver[0][5]=1.3194; SI.m_WHN_driver[0][6]=0.8105; SI.m_WHN_driver[0][7]=-2.4656;
		SI.m_WHN_driver[0][15]=1.2622;  SI.m_WHN_driver[0][14]=0.6806; SI.m_WHN_driver[0][13]=-0.8105; SI.m_WHN_driver[0][12]=0.4656;
		SI.m_WHN_driver[0][11]=-1.2622; SI.m_WHN_driver[0][10]=1.3194; SI.m_WHN_driver[0][9]=0.8105; SI.m_WHN_driver[0][8]=-2.4656;

		MatDoub resp(1,8);

		resp[0][0]=-1.7416;resp[0][1]=2.3432;resp[0][2]=-0.3310;resp[0][3]=-1.1970;
		resp[0][4]=0.7828;resp[0][5]=-0.5880;resp[0][6]=1.2899;resp[0][7]=-0.5581;
		SI.InsertResponseSignals(resp,true);

		resp[0][7]=-1.7416;resp[0][6]=2.3432;resp[0][5]=-0.3310;resp[0][4]=-1.1970;
		resp[0][3]=0.7828;resp[0][2]=-0.5880;resp[0][1]=1.2899;resp[0][0]=-0.5581;		
		SI.InsertResponseSignals(resp,false);

		cout<<"Response Data Full?? -> "<< SI.m_bIsRespDataFull<<endl;

		Mat3DDoub Hmodel;
		Hmodel=SI.GetHModel();
		cout << " H Model Dimention : "<< Hmodel.dim1() << " " << Hmodel.dim2() << " " << Hmodel.dim3() << endl;
		cout << " H Model Value : " << endl;

		cout << Hmodel[0][0][0] << " " << Hmodel[0][0][1] << " " <<Hmodel[0][0][2] << " " <<Hmodel[0][0][3] << " "<<endl;
		cout << Hmodel[0][0][4] << " " << Hmodel[0][0][5] << " " <<Hmodel[0][0][6] << " " <<Hmodel[0][0][7] << " "<<endl;
		cout << endl;

		cout << " Gxx Value : " << endl;
		cout << SI.m_Gxx[0][0][0] << " " << SI.m_Gxx[0][0][1] << " " <<SI.m_Gxx[0][0][2] << " " <<SI.m_Gxx[0][0][3] << " "<<endl;
		cout << SI.m_Gxx[0][0][4] << " " << SI.m_Gxx[0][0][5] << " " <<SI.m_Gxx[0][0][6] << " " <<SI.m_Gxx[0][0][7] << " "<<endl;
		cout << endl;

		cout << " Gxy Value : " << endl;
		cout << SI.m_Gyx[0][0][0] << " " << SI.m_Gyx[0][0][1] << " " <<SI.m_Gyx[0][0][2] << " " <<SI.m_Gyx[0][0][3] << " "<<endl;
		cout << SI.m_Gyx[0][0][4] << " " << SI.m_Gyx[0][0][5] << " " <<SI.m_Gyx[0][0][6] << " " <<SI.m_Gyx[0][0][7] << " "<<endl;
		cout << endl;

		cout << " Xfft Value : " << endl;
		cout << SI.m_Xfft[0][0] << " " << SI.m_Xfft[0][1] << " " <<SI.m_Xfft[0][2] << " " <<SI.m_Xfft[0][3] << " "<<endl;
		cout << SI.m_Xfft[0][4] << " " << SI.m_Xfft[0][5] << " " <<SI.m_Xfft[0][6] << " " <<SI.m_Xfft[0][7] << " "<<endl;
		cout << endl;

		Mat3DDoub tmp2NGxx,tmpInvGxx;

		ComplexMat3DTORealMat3D(SI.m_Gxx,tmp2NGxx);

		CPeudoInverse3D pinverse(tmp2NGxx); 

		RealMat3DTOComplexMat3D(pinverse.GetPinverseMatrix3D(),tmpInvGxx);

		cout << " Inv Gxx Value : " << endl;
		cout << tmpInvGxx[0][0][0] << " " << tmpInvGxx[0][0][1] << " " << tmpInvGxx[0][0][2] << " " << tmpInvGxx[0][0][3] << " "<<endl;
		cout << tmpInvGxx[0][0][4] << " " << tmpInvGxx[0][0][5] << " " << tmpInvGxx[0][0][6] << " " << tmpInvGxx[0][0][7] << " "<<endl;
		cout << endl;


		SI.CalculateINVH();
		Hmodel=SI.GetInvHModel();
		cout << " Inv H Model Dimention : "<< Hmodel.dim1() << " " << Hmodel.dim2() << " " << Hmodel.dim3() << endl;
		cout << " Inv H Model Value : " << endl;

		cout << Hmodel[0][0][0] << " " << Hmodel[0][0][1] << " " <<Hmodel[0][0][2] << " " <<Hmodel[0][0][3] << " "<<endl;
		cout << Hmodel[0][0][4] << " " << Hmodel[0][0][5] << " " <<Hmodel[0][0][6] << " " <<Hmodel[0][0][7] << " "<<endl;
		cout << endl;

// 		///////////////////
//        // TS �����
// 		/////////////////////////
// 		// �ӽ� ���� ����
//         SS.FRONTEND.m_nSlave_Channels=0;
// 		SS.TS.m_nNumberOfChannelOfDesiredSignals=1;
// 		SS.TS.m_nNumberOfPointinDesiredSignals=8;  // ��ǥ��ȣ�� ���μ� ���̴�. �ٸ� BS�� ����� �ƴϴ�.
// 		SS.TS.m_nNumberOfBlockSize=1;
// 
// 		TargetSimulationBase TS;
// 		TS.TSInitialization(SS,Hmodel,resp);
// 		TS.ImportDesiredSignals(resp,0);
// 
// 		Mat3DDoub desiredsignals;
// 		desiredsignals=TS.GetDesiredSignals();
// 
// 		cout << "ORIGINAL Desired Signal  : " << endl;
// 		cout << desiredsignals[0][0][0] << " " << desiredsignals[0][0][1] << " " <<desiredsignals[0][0][2] << " " <<desiredsignals[0][0][3] << " "<<endl;
// 		cout << desiredsignals[0][0][4] << " " << desiredsignals[0][0][5] << " " <<desiredsignals[0][0][6] << " " <<desiredsignals[0][0][7] << " "<<endl;
// 		cout << endl;
// 
// 		cout << "Filtered Desired Signal  : " << endl;
// 		cout << desiredsignals[1][0][0] << " " << desiredsignals[1][0][1] << " " <<desiredsignals[1][0][2] << " " <<desiredsignals[1][0][3] << " "<<endl;
// 		cout << desiredsignals[1][0][4] << " " << desiredsignals[1][0][5] << " " <<desiredsignals[1][0][6] << " " <<desiredsignals[1][0][7] << " "<<endl;
// 		cout << endl;
// 
// 		VecDoub a(1),b(1);
// 		a[0]=1;
// 		b[0]=1;
// 
// 		TS.GenerateFirstDriveSignals(a,b);
// 
// 		MatDoub drivs;
// 		drivs=TS.GetDriveSignals();
// 
// 		cout << "Drive Signal 1 : " << endl;
// 		cout << drivs[0][0] << " " << drivs[0][1] << " " <<drivs[0][2] << " " <<drivs[0][3] << " "<<endl;
// 		cout << drivs[0][4] << " " << drivs[0][5] << " " <<drivs[0][6] << " " <<drivs[0][7] << " "<<endl;
// 		cout << endl;
// 
// 		MatDoub resp1(1,8);
// 
// 		resp1[0][0]=-0.7169;resp1[0][1]= 1.6770;resp1[0][2]=0.1456;resp1[0][3]= -1.0323;
// 		resp1[0][4]= 0.5280;resp1[0][5]= -0.2744;resp1[0][6]= 0.8851;resp1[0][7]=-0.2153;
// 
// 		TS.ImportResponseSignals(resp1,0);
// 
// 		Mat3DDoub respsignals;
// 		respsignals=TS.GetResponseSignals();
// 
// 		cout << "ORIGINAL Resp Signal  : " << endl;
// 		cout << respsignals[0][0][0] << " " << respsignals[0][0][1] << " " <<respsignals[0][0][2] << " " <<respsignals[0][0][3] << " "<<endl;
// 		cout << respsignals[0][0][4] << " " << respsignals[0][0][5] << " " <<respsignals[0][0][6] << " " <<respsignals[0][0][7] << " "<<endl;
// 		cout << endl;
// 
// 		cout << "Filtered Resp Signal  : " << endl;
// 		cout << respsignals[1][0][0] << " " << respsignals[1][0][1] << " " <<respsignals[1][0][2] << " " <<respsignals[1][0][3] << " "<<endl;
// 		cout << respsignals[1][0][4] << " " << respsignals[1][0][5] << " " <<respsignals[1][0][6] << " " <<respsignals[1][0][7] << " "<<endl;
// 		cout << endl;
// 
// 		TS.GenerateUpdatedDriveSignals(a,b);
// 		drivs=TS.GetDriveSignals();
// 
// 		cout << "Drive Signal 2 : " << endl;
// 		cout << drivs[0][0] << " " << drivs[0][1] << " " <<drivs[0][2] << " " <<drivs[0][3] << " "<<endl;
// 		cout << drivs[0][4] << " " << drivs[0][5] << " " <<drivs[0][6] << " " <<drivs[0][7] << " "<<endl;
// 		cout << endl;

/*

SYSTEMSETTING SS;
SS.FRONTEND.m_nInput_Channel=1;
SS.FRONTEND.m_nResponse_Channel=1;
SS.FRONTEND.m_nSlave_Channel=0;
SS.TARGET.m_nNumberOfChannelOfDesiredSignals=1;
SS.TARGET.m_nNumberOfPointinDesiredSignals=16;  // ��ǥ��ȣ�� ���μ� ���̴�. �ٸ� BS�� ����� �ƴϴ�.
SS.SPECTRAL.m_LengthBlocksize=8;
SS.TARGET.m_nNumberOfBlockSize=2;
SS.m_niLimit_Band_Lower=1;
SS.m_niLimit_Band_Upper=4;
SS.SPECTRAL.m_nPshifted=8;
SS.FRONTEND.m_Sampling_Frequency=1;

TargetSimulationBase TS;
TS.TSInitialization(SS);
cout << "m_vecFilter :"<<endl;
MatDoub matd;
matd.Assign(1,16,0.);
for (int i=0; i < 15; i++)
matd[0][i]=sin(2*3.1416*3*i/8);

cout << "sin"<<endl;
cout << matd[0][0]<<" " <<matd[0][1]<<" " <<matd[0][2]<<" " <<matd[0][3]<<" " <<
matd[0][4]<<" " <<matd[0][5]<<" " <<matd[0][6]<<" " <<matd[0][7]<<" " <<endl;
cout << matd[0][8]<<" " <<matd[0][9]<<" " <<matd[0][10]<<" " <<matd[0][11]<<" " <<
matd[0][12]<<" " <<matd[0][13]<<" " <<matd[0][14]<<" " <<matd[0][15]<<" " <<endl;

TS.ImportDesiredSignals(matd);
*/

// cout << TS.m_vecFilter[0]<<" " <<TS.m_vecFilter[1]<<" " <<TS.m_vecFilter[2]<<" " <<TS.m_vecFilter[3]<<" " <<
// TS.m_vecFilter[4]<<" " <<TS.m_vecFilter[5]<<" " <<TS.m_vecFilter[6]<<" " <<TS.m_vecFilter[7]<<" " <<endl;
// SI ����� �κ��̴�.
		/***********************************
		// Method:    SYSTEM_setting_base
		// FullName:  SYSTEM_setting_base
		// Access:    public 
		// Returns:   void
		// Qualifier:
		// Parameter: SYSTEMSETTING & SS
		// Parameter: int nInput_Channel
		// Parameter: int nOuput_Channel
		// Parameter: int nSlave_Channel
		// Parameter: int Sampling_Frequency
		// Parameter: double Scale_Factor
		// Parameter: int Block_Size
		// Parameter: int nCyclic_Aveg
		// Parameter: int pOverlap
		// Parameter: int Window
		// Parameter: double Border_Frequency
		// Parameter: double Alpha
		// Parameter: double STD_White_Noise
		// Parameter: double Time_Interval
		// Parameter: double Limit_Band_Upper
		// Parameter: double Limit_Band_Lower
		/***********************************
*/
/*		SYSTEMSETTING ss;*/

	// 		SYSTEM_setting_base(ss,/*input*/ 1,/*Output*/ 1,/*nSlave_Channel*/0,/*Samplig_Freq*/12,1,
	// 							/*Block_Size*/8,/*nCyclic_Aveg*/1,0,SQARE,/*Border_Frequency*/5,
	// 							/*Alpha*/1,2.7,/*Time_Interval*/30,5,1);
	// 
	// 
	// 
	// 		SYSTEMIDENTIFICATION mSI;
	// 		cout << ss.SI.m_Time_Interval << endl;
	// 		mSI.SIInitialization(ss);
	// 
	// 
	// // 		cout << ss.m_iLimit_Band_Lower << " " << ss.SI.m_iBorder_Frequency << " " << ss.m_iLimit_Band_Upper <<endl;
	// // 		cout << " nWhite_added : " << ss.SI.m_nWhite_added << endl;
	// 	
	// 		cin >> tempkey;
	// 		mSI.WhiteNoiseGeneration();
	// 		cout << " WHN Generated " << endl;

// 		cin >> tempkey;
// 		cout << ss.m_iLimit_Band_Lower << " " << ss.SI.m_iBorder_Frequency << " " << ss.m_iLimit_Band_Upper <<endl;
// 		cout << ss.FRONTEND.m_Sampling_Frequency << endl;
	


// 			MatDoub wn=mSI.GetWhiteNoise();
// 
// 			cout << "WHN " <<endl;
// 			for (int i=0 ; i < ss.SPECTRAL.m_LengthBlocksize*5 ; i++)
// 			cout << wn[0][i] <<endl;
// 
// 
// 			MatDoub A(1,8,2);
// 			
// 			A[0][2]=3;
// 			A[0][6]=7;
// 	// 		A[0][10]=3;
// 	// 		A[0][14]=7;
// 			cout << " 1 " << endl;
// 			mSI.TakeResponseSignals(A,true);
// 			cout << " TakeResponseSignals Generated " << endl;
// 
// 
// 			cin >> tempkey;
// 			cout << " 2 " << endl;
// 			//	A.~NRmatrix();
// 			mSI.CalculatePSD();
// 					cout << " CalculatePSD Generated " << endl;
// 
// 			cin >> tempkey;
// 			cout << " 3 " << endl;
// 			mSI.CalculateH();
// 					cout << " CalculateH Generated " << endl;
// 
// 			cin >> tempkey;
// 			cout << " 4 " << endl;
// 
// 			//cout << "   = 6=  " << endl;
// 
// 			mSI.CalculateINVH();
// 					cout << " CalculateINVH Generated " << endl;
// 		
// 			cin >> tempkey;
// 			cout << " 5 " << endl;
// 			mSI.debugging();
// 			cout << " ==6== " << endl;
// 			mSI.CalculateOrdinaryCOH();
// 			cout << " ==7== " << endl;
// 
// 			MatDoub K(2,2,1.);
// 			SVD SVDA;
// 			SVDA.SVDInitialization(K);
// 			SVDA.PeudoInverseMatrix();

// SI ����� �κ��̴�.



//����Ÿ ����Ʈ, ������Ʈ �κ��̴�.
/*
 char **pos=NULL;
 char *pos2=NULL;
 char *p=NULL;
char *stopstring=NULL;
char *stopstring2=NULL;
string a="     1e-001 1e-002\n1e+002";

	double b=strtod(a.data(),&stopstring);
	if ( a.data()==stopstring ) cout << " D1" <<endl;
	double c=strtod(stopstring,&stopstring2);
	if ( stopstring==stopstring2 ) cout << " D2" <<endl;
	double d=strtod(stopstring2,&stopstring);
	if ( stopstring==stopstring2 )cout << " D3" <<endl;
	double e=strtod(stopstring,&stopstring2);
	if ( stopstring==stopstring2 )cout << " D4" <<endl;
	cout<<b<<" "<<c<<" " <<d<<e<<endl;


	int       IndexPre=0;
	double    LENGTH[100];
	double    DELTA[100];
	int		  NumberOfSignals=0;
	string	  CHANNELNAME[100];
	string	  UNIT[100];
	char	  tempChar[1000];

	// ���� �ڵ� ����
	ifstream fin("uftar.txt");
	// ù���� �д´�.
	fin.getline(tempChar,1000,'\n');

	// ù���� ���� �������� �Ǻ�
	if(strcmp(tempChar,"BEGIN")== 0)
	{
		// END�� ������ ������ ���� ����
		while( true )
		{

			// 20�� �̻� �Ǻ��ϰ� ������ ������� ����. 
			// �� END�� �����ϴ��� �Ǻ��ϴ� ���̴�.
			if (IndexPre++ > 20 ) throw(" __");

			fin >> tempChar;

// 			if (strcmp(tempChar,"COLUMNWIDTH")== 0)
// 			{
// 				while( fin.get()!= '\n') continue;
// 			}
// 
// 			else if (strcmp(tempChar,"COLUMNOFFSET")== 0)
// 			{
// 				while( fin.get()!= '\n') continue;
// 			}
// 			else if (strcmp(tempChar,"MINIMUM")== 0)
// 			{
// 				while( fin.get()!= '\n') continue;
// 			}
// 			else if (strcmp(tempChar,"MAXIMUM")== 0)
// 			{
// 				while( fin.get()!= '\n') continue;
// 			}
// 			else if (strcmp(tempChar,"START")== 0)
// 			{
// 				while( fin.get()!= '\n') continue;
// 			}
// 
// 			else if (strcmp(tempChar,"#")== 0)
// 			{
// 				while( fin.get()!= '\n') continue;
// 			}
// 			
// 			else if ( strcmp(tempChar,"CHANNELNAME")== 0)

			if ( strcmp(tempChar,"CHANNELNAME")== 0)
			{
				for ( int k=0 ; k<1000 ; k++)
				{
					if ( fin.peek() == ']') break;
					if ( k>900 ) throw("���� �����ʰ�");
					fin.getline(tempChar,1000,'\'');// ���ſ�			
					fin.getline(tempChar,1000,'\'');// ���� ����
					CHANNELNAME[k]=tempChar;
					NumberOfSignals=k+1;
				}
				while( fin.get()!= '\n') continue;

			}
			else if ( strcmp(tempChar,"LENGTH")== 0)
			{
				if (NumberOfSignals < 1 ) throw("__INDEX");
				fin.getline(tempChar,1000,'[');
				for (int k=0 ; k< NumberOfSignals-1 ;k++)
				{			
					fin.getline(tempChar,1000,',');
					LENGTH[k]=strtod(tempChar,NULL);

				}
				fin.getline(tempChar,1000,']');
				LENGTH[NumberOfSignals-1]=strtod(tempChar,NULL);
				while( fin.get()!= '\n') continue;
			}
			else if ( strcmp(tempChar,"UNIT")== 0)
			{
				for ( int k=0 ; k<1000 ; k++)
				{
					if ( fin.peek() == ']') break;
					if ( k>900 ) throw("���� �����ʰ�");
					fin.getline(tempChar,1000,'\'');// ���ſ�			
					fin.getline(tempChar,1000,'\'');// ���� ����
					UNIT[k]=tempChar;
				}
				while( fin.get()!= '\n') continue;
			}
			else if ( strcmp(tempChar,"DELTA")== 0)
			{
				if (NumberOfSignals < 1 ) throw("__INDEX");
				fin.getline(tempChar,1000,'[');
				for (int k=0 ; k< NumberOfSignals-1 ;k++)
				{			
					fin.getline(tempChar,1000,',');
					DELTA[k]=strtod(tempChar,NULL);

				}
				fin.getline(tempChar,1000,']');
				DELTA[NumberOfSignals-1]=strtod(tempChar,NULL);
				while( fin.get()!= '\n') continue;
			}
			// Ż����̴�. �� ������ ������ IndexPre�� ���� ������ �߻��Ѵ�.
			else if (strcmp(tempChar,"END")== 0)
			{
				break; 
			}
			else
			{
				while( fin.get()!= '\n') continue;
			}
		}
	}
	else
	{
		throw("__");
	}

	MatDoub DesiredSignals(NumberOfSignals,int(LENGTH[0]));

	
		for (int j=0 ; j < LENGTH[0] ; j++)
		for (int i=0 ; i < NumberOfSignals ; i++)
		{
			fin>>tempChar;
			DesiredSignals[i][j]=strtod(tempChar,NULL);
		}


	cout << "Result"<<endl;
	cout << NumberOfSignals<<endl;
	cout << CHANNELNAME[0] << CHANNELNAME[1]<<CHANNELNAME[2]<<endl;
	cout << UNIT[0] << UNIT[1]<<UNIT[2]<<endl;
	cout << LENGTH[0] << LENGTH[1]<<LENGTH[2]<<endl;
	cout << DELTA[0] << DELTA[1]<<DELTA[2]<<endl;
	
	for ( int j=0; j < 10; j++)
	cout << DesiredSignals[0][j]<< " " <<DesiredSignals[1][j]<< " " <<DesiredSignals[2][j]<< " " <<endl;
*/ 
//����Ÿ ����Ʈ ������Ʈ �κ��̴�.





/*
		SYSTEMSETTING ss;
		// ************************************
		// Method:    SYSTEM_setting_base
		// FullName:  SYSTEM_setting_base
		// Access:    public 
		// Returns:   void
		// Qualifier:
		// Parameter: SYSTEMSETTING & SS
		// Parameter: int nInput_Channel
		// Parameter: int nOuput_Channel
		// Parameter: int Sampling_Frequency
		// Parameter: double Scale_Factor
		// Parameter: int Block_Size
		// Parameter: int nCyclic_Aveg
		// Parameter: int pOverlap
		// Parameter: int Window
		// Parameter: double Border_Frequency
		// Parameter: double Alpha
		// Parameter: double STD_White_Noise
		// Parameter: double Time_Interval
		// Parameter: double Limit_Band_Upper
		// Parameter: double Limit_Band_Lower
		// ************************************
		SYSTEM_setting_base(ss,/ *input* / 1,/ *Output* / 1,/ *Samplig_Freq* /300,1,/ *BS* /8,/ *Cyclic AVG* /1,/ *pOverlap* /50,SQARE,100,1,2,30,100,0);
		SYSTEMIDENTIFICATION mSI(ss);
		mSI.SIInitialization(ss);


//		cout << ss.m_iLimit_Band_Lower << " " << ss.SI.m_iBorder_Frequency << " " << ss.m_iLimit_Band_Upper <<endl;
//		cout << " nWhite_added : " << ss.SI.m_nWhite_added << endl;

		mSI.WhiteNoiseGeneration();
//		cout << ss.m_iLimit_Band_Lower << " " << ss.SI.m_iBorder_Frequency << " " << ss.m_iLimit_Band_Upper <<endl;
//		cout << ss.FRONTEND.m_Sampling_Frequency << endl;

		MatDoub A(1,8,2.);
		A[0][2]=3;
		A[0][3]=4;
//		A[0][17]=6;
//		cout << "A[0][3] "<<A[0][3]<<endl;
		mSI.TakeResponseSignals(A);

		//	A.~NRmatrix();
		mSI.CalculatePSD();
		mSI.CalculateH();

/ * 

		cout << "   = 6=  " << endl;* /

		mSI.CalculateINVH();
//		mSI.debugging();

		MatDoub B(1,8,2.);
		B[0][1]=9;
		mSI.TakeResponseSignals(B);

		//	A.~NRmatrix();
		mSI.CalculatePSD();
		mSI.CalculateH();


		cout << "   = 6=  " << endl;

		mSI.CalculateINVH();
//		mSI.debugging();


		mSI.CalculateOrdinaryCOH();*/
		/////////////////////////////
		/////////////////////////////
/*
	Mat3DDoub AA;
	AA.AssignConstant(1,4,4,1.);
	AA[0][0][2]=5;
	cout << AA[0][0][0] << " " << AA[0][0][1] << " " << AA[0][0][2] << " " << AA[0][0][3] << " " << endl;
	cout << AA[0][1][0] << " " << AA[0][1][1] << " " << AA[0][1][2] << " " << AA[0][1][3] << " " << endl;
	cout << AA[0][2][0] << " " << AA[0][2][1] << " " << AA[0][2][2] << " " << AA[0][2][3] << " " << endl;
	cout << AA[0][3][0] << " " << AA[0][3][1] << " " << AA[0][3][2] << " " << AA[0][3][3] << " " << endl;
	MatDoub BB(1,8,6);
	rlft3(AA,BB,1);

	cout << AA[0][0][0] << " " << AA[0][0][1] << " " << AA[0][0][2] << " " << AA[0][0][3] << " " << endl;
	cout << AA[0][1][0] << " " << AA[0][1][1] << " " << AA[0][1][2] << " " << AA[0][1][3] << " " << endl;
	cout << AA[0][2][0] << " " << AA[0][2][1] << " " << AA[0][2][2] << " " << AA[0][2][3] << " " << endl;
	cout << AA[0][3][0] << " " << AA[0][3][1] << " " << AA[0][3][2] << " " << AA[0][3][3] << " " << endl;
	cout <<endl;
	cout << BB[0][0] << " " <<BB[0][1] << " " <<BB[0][2] << " " <<BB[0][3] << " " <<BB[0][4] << " " <<BB[0][5] << " " <<BB[0][6] << " " <<BB[0][7] << " " <<endl;

*/
	}
	catch (int e)
	{
		cout << e <<endl;
	}

cin >> tempkey;
}

