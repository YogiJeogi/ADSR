#include "System.h"

CSystem::CSystem(void)
{

}

CSystem::~CSystem(void)
{
}

void CSystem::NewProject( string PathName, string FileName, string FileExt )
{
}

void CSystem::OpenProject(string PathName, string FileName, string FileExt)
{
}

void CSystem::SaveProject(void)
{
	return ;
}

void CSystem::SaveAsProject(string PathName, string FileName, string FileExt)
{
}

void CSystem::CloseProject(void)
{
}


void CSystem::SaveTemIterationResult(void)
{
}
