#pragma once
#ifndef __BASEHD_H__
#define __BASEHD_H__

#include "fourier.h"
#include "ran.h"
#include "preferST.h"
#include "spectrum.h"
#include "svd.h"
#include "Matcalf.h"
//#include "WNG.h"


#endif
